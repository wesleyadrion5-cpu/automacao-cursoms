import React, { useState, useEffect, useRef } from 'react';
import { MappedRow, LogEntry, AutomationState } from './types';
import TerminalConsole from './components/TerminalConsole';
import StatusCard from './components/StatusCard';
import SpreadsheetLoader from './components/SpreadsheetLoader';
import PythonCodeHub from './components/PythonCodeHub';
import {
  Home,
  Bot,
  Play,
  Pause,
  RotateCcw,
  Settings,
  Minimize2,
  Maximize2,
  X,
  Code,
  Sliders,
  Sparkles,
  HelpCircle
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'python'>('dashboard');
  const [rows, setRows] = useState<MappedRow[]>([]);
  const [processedCount, setProcessedCount] = useState(4);
  const [progressPercent, setProgressPercent] = useState(75);
  const [automationState, setAutomationState] = useState<AutomationState>('IDLE');
  const [columnMapping, setColumnMapping] = useState({
    modulo: 'NOMES MAPEADOS',
    video: 'MÍDIA / VÍDEO',
    duracao: 'DURAÇÃO',
    extra: 'FASES',
  });
  
  const [robotName, setRobotName] = useState('Robô 1');
  const [delay, setDelay] = useState(1500); // milliseconds
  const [autoScrollLogs, setAutoScrollLogs] = useState(true);

  // Initial preloaded logs to match the user's screenshot exactly!
  const [logs, setLogs] = useState<LogEntry[]>([
    { id: 'l1', timestamp: '10:17:00', level: 'INFO', message: `[${robotName}] Iniciando conexão com o banco de dados de mapeamento...` },
    { id: 'l2', timestamp: '10:17:02', level: 'SUCCESS', message: `[${robotName}] Vídeo 1 extraído: "Trilha Estratégica - Vídeo 1"` },
    { id: 'l3', timestamp: '10:17:02', level: 'INFO', message: `[${robotName}] Vídeo 2 extraído: "Satalia - Vídeo 1"` },
    { id: 'l4', timestamp: '10:17:04', level: 'INFO', message: `[${robotName}] Extraindo vídeo 3/9...` },
    { id: 'l5', timestamp: '10:17:04', level: 'INFO', message: `[${robotName}] Extraindo vídeo 4/9...` },
  ]);

  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Preload standard rows on startup to give a populated feel
  useEffect(() => {
    const startupSamples: MappedRow[] = [
      { id: '1', modulo: 'Módulo 1: Fundamentos Organizacionais', video: 'Trilha Estratégica - Vídeo 1', duracao: '12:15', extra: 'Fase 1' },
      { id: '2', modulo: 'Módulo 1: Fundamentos Organizacionais', video: 'Satalia - Vídeo 1', duracao: '10:45', extra: 'Fase 1' },
      { id: '3', modulo: 'Módulo 2: Arquitetura Complexa', video: 'Extraindo Vídeo 3/9', duracao: '15:20', extra: 'Fase 2' },
      { id: '4', modulo: 'Módulo 2: Arquitetura Complexa', video: 'Trilha Estratégica - Vídeo 2', duracao: '08:50', extra: 'Fase 2' },
      { id: '5', modulo: 'Módulo 3: Consolidação de Dados', video: 'Integração Final - Vídeo 1', duracao: '18:30', extra: 'Fase 3' },
      { id: '6', modulo: 'Módulo 3: Consolidação de Dados', video: 'Painel Geral - Vídeo 2', duracao: '14:15', extra: 'Fase 3' },
      { id: '7', modulo: 'Módulo 4: Monitoramento Avançado', video: 'Auditória Geral - Vídeo 1', duracao: '09:40', extra: 'Fase 4' },
      { id: '8', modulo: 'Módulo 4: Monitoramento Avançado', video: 'Segurança Operacional - Vídeo 2', duracao: '11:05', extra: 'Fase 4' },
      { id: '9', modulo: 'Módulo 5: Implantação e Release', video: 'Pipeline de Produção - Vídeo 3', duracao: '13:50', extra: 'Fase 5' },
      { id: '10', modulo: 'Módulo 5: Implantação e Release', video: 'Checklist de Entrega - Vídeo 4', duracao: '16:00', extra: 'Fase 5' },
    ];
    setRows(startupSamples);
  }, []);

  // Sync circular bar with processed count on startup or rows update
  useEffect(() => {
    if (automationState === 'IDLE') {
      if (rows.length > 0) {
        const pCount = Math.min(4, rows.length);
        setProcessedCount(pCount);
        setProgressPercent(Math.round((pCount / rows.length) * 100));
      } else {
        setProcessedCount(0);
        setProgressPercent(0);
      }
    }
  }, [rows, automationState]);

  const addLog = (level: 'INFO' | 'SUCCESS' | 'WARNING' | 'ERROR', message: string) => {
    const timestamp = new Date().toLocaleTimeString('pt-BR', { hour12: false });
    const newLog: LogEntry = {
      id: String(Date.now()) + Math.random().toString(36).substring(2, 5),
      timestamp,
      level,
      message,
    };
    setLogs((prev) => [...prev, newLog]);
  };

  // Robot Action 1: Prepara o Robô
  const handlePrepareRobot = () => {
    if (rows.length === 0) {
      addLog('ERROR', 'Impossível carregar. Nenhuma planilha ou arquivo mapeado carregado.');
      return;
    }
    setAutomationState('PREPARED');
    addLog('INFO', `[${robotName}] Iniciando preparação do motor de rastreamento...`);
    addLog('INFO', `[${robotName}] Mapeamento carregado: ${rows.length} estruturas de módulo identificadas.`);
    addLog('INFO', `[${robotName}] Colunas vinculadas: [ID/Modulo: ${columnMapping.modulo}], [Alvo Vídeo: ${columnMapping.video}].`);
    addLog('SUCCESS', `[${robotName}] Pré-compilação bem-sucedida! Pronto para clicar em COMEÇAR AUTOMAÇÃO.`);
  };

  // Robot Action 2: Começar Automação (Loops through loaded rows simulating process)
  const handleStartAutomation = () => {
    if (rows.length === 0) {
      addLog('ERROR', 'Falha ao iniciar automação: carregue uma planilha antes de começar.');
      return;
    }

    if (automationState === 'MIGRATING') {
      // Pause
      setAutomationState('PAUSED');
      addLog('WARNING', `[${robotName}] Loop de automação suspenso pelo operador.`);
      if (intervalRef.current) clearInterval(intervalRef.current);
      return;
    }

    let currentIndex = automationState === 'PAUSED' ? processedCount : 0;
    setAutomationState('MIGRATING');
    addLog('SUCCESS', `[${robotName}] Iniciando motor de migração cíclico.`);

    const totalToProcess = rows.length;

    // Direct interval ticks representing steps
    intervalRef.current = setInterval(() => {
      if (currentIndex >= totalToProcess) {
        setAutomationState('COMPLETED');
        addLog('SUCCESS', `[${robotName}] === AUTOMAÇÃO CONCLUÍDA! ${totalToProcess} módulos novos integrados ao sistema. ===`);
        if (intervalRef.current) clearInterval(intervalRef.current);
        return;
      }

      const activeRow = rows[currentIndex];
      addLog('INFO', `[${robotName}] Processando item (${currentIndex + 1}/${totalToProcess})`);
      addLog('INFO', `[${robotName}] Criando Módulo: "${activeRow.modulo}" no ambiente de destino.`);
      
      // Simulating a delay for extraction
      setTimeout(() => {
        addLog('SUCCESS', `[${robotName}] Vídeo vinculado com sucesso: "${activeRow.video}" (Duração de ${activeRow.duracao})`);
        const nextProcessed = currentIndex + 1;
        setProcessedCount(nextProcessed);
        setProgressPercent(Math.round((nextProcessed / totalToProcess) * 100));
        currentIndex++;
      }, delay * 0.4);

    }, delay);
  };

  const handleResetRobot = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setAutomationState('IDLE');
    setProcessedCount(0);
    setProgressPercent(0);
    addLog('WARNING', `[${robotName}] Estado do robô redefinido de forma segura. Contador zerado.`);
  };

  // Clean-up on unmount
  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  return (
    <div className="min-h-screen bg-[#0d131a] text-slate-100 flex flex-col font-sans transition-colors duration-300">
      
      {/* OS App mock Header title bar */}
      <header className="bg-[#0b0f14] border-b border-slate-900 px-4 py-2.5 flex items-center justify-between shrink-0 select-none">
        <div className="flex items-center gap-3">
          {/* Cyan pulsing dot */}
          <div className="flex items-center justify-center bg-cyan-950/40 p-1.5 rounded-lg border border-cyan-800/30 text-[#00f2fe]">
            <Bot className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h1 className="text-sm font-sans font-extrabold tracking-wide text-slate-100">
              Dona Francisca
            </h1>
            <p className="text-[10px] font-mono tracking-wider text-cyan-400 font-bold uppercase leading-tight">
              Automação de módulos Mapeados
            </p>
          </div>
        </div>

        {/* Outer window controls mockup */}
        <div className="flex items-center gap-4 text-slate-500">
          <div className="flex items-center gap-1">
            <button className="p-1 hover:text-slate-300 hover:bg-slate-800/40 rounded transition">
              <Settings className="w-4 h-4" />
            </button>
            <button className="p-1 hover:text-slate-300 hover:bg-slate-800/40 rounded transition">
              <Minimize2 className="w-3.5 h-3.5" />
            </button>
            <button className="p-1 hover:text-slate-300 hover:bg-slate-800/40 rounded transition">
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
            <button className="p-1 hover:text-red-400 hover:bg-red-950/20 rounded transition">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main OS Body layout */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Left Drawer Side Navigation tab bar */}
        <nav className="w-52 bg-[#0a0f14] border-r border-slate-900 p-3 shrink-0 flex flex-col gap-1 select-none">
          <span className="text-[9px] font-mono tracking-widest text-slate-600 uppercase pl-3 mb-2 block font-extrabold">
            Navegação
          </span>

          {/* Button tab: Dashboard */}
          <div
            className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs font-mono font-medium bg-gradient-to-r from-cyan-950/60 to-[#122330] border-l-2 border-[#00f2fe] text-[#00f2fe]"
          >
            <Home className="w-4 h-4 shrink-0" />
            Home / Painel
          </div>

          <div className="h-[1px] bg-slate-900/80 my-4" />

          {/* Informative credentials status board */}
          <div className="mt-auto p-3.5 rounded-xl bg-slate-950 border border-slate-900 text-[11px] font-mono space-y-2.5">
            <span className="text-[10px] font-bold text-slate-500 block uppercase">
              REQUISITOS / STATUS
            </span>
            <div className="space-y-1.5 text-slate-400 text-[10px]">
              <div className="flex items-center justify-between">
                <span>Pandas:</span>
                <span className="text-emerald-400 font-bold">✔ OK</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Antigravity:</span>
                <span className="text-emerald-400 font-bold">✔ Ativo</span>
              </div>
            </div>
            
            <div className="pt-2 text-center border-t border-slate-900">
              <span className="text-[9px] text-[#00f2fe]/80 bg-cyan-950/30 px-1 py-0.5 rounded font-extrabold uppercase">
                Versão 1.2
              </span>
            </div>
          </div>
        </nav>

        {/* Right Dashboard Client Workspace Container */}
        <main className="flex-1 bg-[#0d131a] overflow-y-auto p-6 md:p-8 space-y-6">
          
          <div className="space-y-6">
            
            {/* Heading Tab */}
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-extrabold tracking-tight text-white mb-1.5">
                  Início Rápido
                </h2>
                <p className="text-slate-400 text-xs font-mono">
                  Gerencie a fila de extração de vídeos e configure o ciclo de migração do robô.
                </p>
              </div>

              <div className="flex items-center gap-2">
                {/* Reset count */}
                <button
                  onClick={handleResetRobot}
                  title="Resetar progresso"
                  className="p-2 border border-slate-800 hover:border-slate-700 bg-[#121921] text-slate-400 hover:text-slate-200 rounded-lg transition duration-200"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
                
                <div className="text-xs font-mono text-slate-500 bg-slate-950/80 px-3 py-2 border border-slate-900 rounded-lg">
                  Delay Ativo: <span className="text-cyan-400 font-bold">{(delay / 1000).toFixed(1)}s</span>
                </div>
              </div>
            </div>

            {/* Bento Grid layout with 3 active Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-6 items-stretch">
              
              {/* Column 1: NOMES MAPEADOS / SpreadsheetLoader block */}
              <div className="lg:col-span-5 h-full">
                <SpreadsheetLoader
                  rows={rows}
                  onRowsChange={setRows}
                  columnMapping={columnMapping}
                  onMappingChange={setColumnMapping}
                  onLogAdd={addLog}
                />
              </div>

              {/* Column 2: STACKED COMANDO BUTTONS */}
              <div className="lg:col-span-3 flex flex-col justify-center gap-4">
                {/* PREPARAR ROBÔ BUTTON */}
                <button
                  onClick={handlePrepareRobot}
                  className={`group w-full py-6 px-4 rounded-xl border flex flex-col items-center justify-center gap-3 transition-all duration-300 font-mono text-xs uppercase font-extrabold tracking-widest ${
                    automationState === 'PREPARED' || automationState === 'MIGRATING' || automationState === 'COMPLETED'
                      ? 'bg-slate-900/60 border-slate-800 text-slate-500 cursor-default'
                      : 'bg-cyan-500/10 hover:bg-cyan-500/20 text-[#00f2fe] border-cyan-500/25 hover:shadow-[0_0_15px_rgba(0,242,254,0.15)] cursor-pointer'
                  }`}
                >
                  <Bot className={`w-10 h-10 transition-transform ${automationState === 'IDLE' ? 'group-hover:scale-110 text-[#00f2fe]' : 'text-slate-600'}`} />
                  <span className="text-center">PREPARAR ROBÔ</span>
                </button>

                {/* COMEÇAR AUTOMAÇÃO BUTTON */}
                <button
                  onClick={handleStartAutomation}
                  disabled={rows.length === 0}
                  className={`group w-full py-6 px-4 rounded-xl border flex flex-col items-center justify-center gap-3 transition-all duration-300 font-mono text-xs uppercase font-extrabold tracking-widest cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${
                    automationState === 'MIGRATING'
                      ? 'bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border-amber-500/20'
                      : 'bg-cyan-500/15 hover:bg-cyan-500/25 text-[#00f2fe] border-cyan-500/30 font-bold hover:shadow-[0_0_20px_rgba(0,242,254,0.2)]'
                  }`}
                >
                  {automationState === 'MIGRATING' ? (
                    <Pause className="w-10 h-10 text-amber-400 animate-pulse" />
                  ) : (
                    <Play className="w-10 h-10 text-cyan-400 group-hover:scale-110 transition-transform" />
                  )}
                  <span className="text-center">
                    {automationState === 'MIGRATING' ? 'PAUSAR AUTOMAÇÃO' : 'COMEÇAR AUTOMAÇÃO'}
                  </span>
                </button>
              </div>

              {/* Column 3: RADIAL AND LINEAR PROGRESS CARD */}
              <div className="lg:col-span-4 h-full">
                <StatusCard
                  processed={processedCount}
                  total={rows.length}
                  percent={progressPercent}
                />
              </div>

            </div>

            {/* Console log footer section */}
            <TerminalConsole
              logs={logs}
              automationState={automationState}
              onClearLogs={() => setLogs([])}
              autoScroll={autoScrollLogs}
              onToggleAutoScroll={() => setAutoScrollLogs(!autoScrollLogs)}
            />

          </div>

        </main>
      </div>

    </div>
  );
}
